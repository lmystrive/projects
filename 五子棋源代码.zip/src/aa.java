import java.sql.*;
//数据库连接
class a {
    private static final String URL = "jdbc:mysql://localhost:3306/wuziqi?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";
    private static Connection conn = null;
    /**
     * 获取数据库连接
     *
     * @return
     * @throws SQLException
     */
    public static Connection getConn() throws SQLException {
        if (conn == null || conn.isClosed())//当前没有连接或者连接处于关闭状态，才去创建新的连接
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        return conn;
    }
    /**
     * 关闭连接
     */
    public static void closeConn() {
        try {
            if (conn != null && !conn.isClosed())//有连接并且连接没有关闭的时候才去关闭连接
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
//MySQL的增删减查
class b {
    /* 1、新增:往player表中添加一个名称为john、获胜三场的记录 */
    public void testInsert() throws SQLException{
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        //注册驱动并获取连接
        conn = a.getConn();
        //获取传输器
        stat = conn.createStatement();
        //发送sql语句到服务器执行,并返回执行结果
        String sql = "insert into player values(null, 'john', 获胜三场)";
        int rows = stat.executeUpdate(sql);
        //处理结果
        System.out.println("影响行数: " + rows);
    }
    /* 2、修改:将player表中名称为john的记录，修改为获胜两场 */
    public void testUpdate() {
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        try {
            //注册驱动并获取连接
            conn = a.getConn();
            //获取传输器
            stat = conn.createStatement();
            //发送sql语句到服务器执行,并返回执行结果
            String sql = "update player set 胜场数=2 where name='john'";
            int rows = stat.executeUpdate(sql);
            //处理结果
            System.out.println("影响行数: " + rows);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /* 3、查询:查询player表中id为john的记录 */
    public void testFindById() throws SQLException {
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        try {
            //注册驱动并获取连接
            conn = a.getConn();
            //获取传输器
            stat = conn.createStatement();
            //执行sql语句,返回执行结果
            String sql = "select * from player where account=john";
            rs = stat.executeQuery(sql);
            //处理结果
            if (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                double money = rs.getDouble("money");
                System.out.println(id + " : " + name + " : " + money);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /* 4、删除:删除player表中名称为john的记录 */
    public void testDelete() {
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        try {
            //注册驱动并获取连接
            conn = a.getConn();
            //获取传输器
            stat = conn.createStatement();
            //发送sql语句到服务器执行,并返回执行结果
            String sql = "delete from player where name='john'";
            int rows = stat.executeUpdate(sql);
            //处理结果
            System.out.println("影响行数: " + rows);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

