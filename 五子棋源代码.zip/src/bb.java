import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
public class bb{
    public static void main(String[] args) {
        Test6 text6=new Test6();
        text6.init();
    }
}
class Test6 extends JFrame {
    //创建文本标签和文本框
    JLabel username=new JLabel(" 用户名 ");//设置用户名文本框
    JLabel password=new JLabel("   密码   ");//设置密码文本框
    JTextField usernamel=new JTextField(18);
    JTextField passwordl=new JTextField(18);
    //创建一个容器用来储存
    JPanel jp=new JPanel();
    //注册和登录的按钮
    JButton jbutton1=new JButton("注册");
    JButton jbutton2=new JButton("登录");
    public Test6() {
        Toolkit t=Toolkit.getDefaultToolkit();//工具类
        Dimension d=t.getScreenSize();
        int height=(int)d.getHeight();//得到显示屏的高度
        int width=(int)d.getWidth();//得到显示屏的宽度
        this.setBounds((width-290)/2, (height-180)/2, 290, 180);//设置一个宽为290，高为200的窗口，并且让窗口居中
        this.setDefaultCloseOperation(3);//关闭窗口的同时，结束运行
        this.setTitle("登录系统");//窗口标题
        init();
        this.setVisible(true);//让窗口显示
    }
    public void init() {
        //将内容添加到容器中
        jp.add(username);
        jp.add(usernamel);
        jp.add(password);
        jp.add(passwordl);
        jp.add(jbutton1);
        jp.add(jbutton2);
        jbutton1.addActionListener(new ActionListener() {//添加监听器
            //将用户名和密码写入文件中的操作
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    BufferedWriter w=new BufferedWriter(new FileWriter("D:/登录.txt",true));
                    String sum=usernamel.getText()+" "+passwordl.getText();//中间加了空格是为了确保后续登录与文件数据匹配的稳定性
                    BufferedReader r=new BufferedReader(new FileReader("D:/登录.txt"));
                    boolean cot=true;
                    String s;
                    while((s=r.readLine())!=null) {
                        if(sum.equals(s)) {
                            cot=false;//如果符合其中一条数据，说明该数据就已经存在了，就不能在注册
                        }
                    }
                    if(cot) {
                        w.write(sum);
                        w.newLine();
                        w.flush();
                        w.close();
                        JOptionPane.showMessageDialog(null, "注册成功！");//对按了注册按钮做出的回应
                    }else {
                        JOptionPane.showMessageDialog(null, "已经存在了，请更换用户名和密码！");//对按了注册按钮做出的回应
                    }
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        });
        jbutton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String sum=usernamel.getText()+" "+passwordl.getText();//中间加了空格是为了确保与文件数据匹配的稳定性
                //对用户名和密码进行匹配
                boolean cot=false;
                String s;
                try {
                    BufferedReader r=new BufferedReader(new FileReader("D:/登录.txt"));
                    while((s=r.readLine())!=null) {
                        if(s.equals(sum)) {
                            cot=true;//如果符合其中一条数据，就为登录成功
                        }
                    }
                    //对按登录按钮做出的回应
                    if(cot) {
                        JOptionPane.showMessageDialog(null, "登录成功！");
                    }else {
                        JOptionPane.showMessageDialog(null, "用户名或者密码错误，登录失败！");
                    }
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        this.add(jp);
    }
}


