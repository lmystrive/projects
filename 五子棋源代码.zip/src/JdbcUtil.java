import java.sql.*;
//数据库连接
class JdbcUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/wuziqi?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";
    private static Connection conn = null;
    /**
     * 获取数据库连接
     *
     * @return
     * @throws SQLException
     */
    public static Connection getConn() throws SQLException {
        if (conn == null || conn.isClosed())//当前没有连接或者连接处于关闭状态，才去创建新的连接
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        return conn;
    }
    /**
     * 关闭连接
     */
    public static void closeConn() {
        try {
            if (conn != null && !conn.isClosed())//有连接并且连接没有关闭的时候才去关闭连接
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws SQLException {
        Connection connection = JdbcUtil.getConn();
        String sql = "select paccount from players";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();//表示数据库结果集的数据表，通过执行查询数据库的语句生成
        while (rs.next())//将指针移动到下一行，然后while循环迭代遍历ResultSet对象
        {
            System.out.println(rs.getString("paccount"));
        }
    }
    //登陆按钮的实现
    public static boolean selectPlayer(String id, String password) throws SQLException {
        Connection connection = JdbcUtil.getConn();
        String sql = "select ppassword from players";
        PreparedStatement ps = connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();//表示数据库结果集的数据表，通过执行查询数据库的语句生成
        while (rs.next())//将指针移动到下一行，然后while循环迭代遍历ResultSet对象
        {
            if (rs.getString("ppassword").equals(password)) {
                return true;
            }
        }
        return false;
    }
    //注册按钮的实现
    public static boolean registerPlayer( String paccount) throws SQLException {
        Connection connection = JdbcUtil.getConn();
        String sql = "select paccount from players";
        PreparedStatement ps = connection.prepareStatement(sql);
        ResultSet rs1 = ps.executeQuery();//表示数据库结果集的数据表，通过执行查询数据库的语句生成
        while (rs1.next())//将指针移动到下一行，然后while循环迭代遍历ResultSet对象
        {
            if (rs1.getString("paccount").equals(paccount)) {
                return false;
            }
        }
        return true;
    }
    //向表里面添加注册的账号信息
    public static boolean newPlayer(String id,String password)throws SQLException{
        Connection connection=JdbcUtil.getConn();
        String sql="insert players(paccount,ppassword) values(?,?)";
        PreparedStatement ps=connection.prepareStatement(sql);//定义预编译的sql语句
        ps.setString(1,id);
        ps.setString(2,password);
        int num=ps.executeUpdate();
        if(num>0){
            return true;
        }else
            return false;
    }
}